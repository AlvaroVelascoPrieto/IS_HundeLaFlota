package packModelo;

public class Bomba extends Arma {
}
