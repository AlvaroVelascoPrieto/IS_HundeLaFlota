package packModelo;


public class Misil extends Arma {
}