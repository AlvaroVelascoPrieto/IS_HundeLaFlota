package packModelo;

public class Escudo extends Arma {
}