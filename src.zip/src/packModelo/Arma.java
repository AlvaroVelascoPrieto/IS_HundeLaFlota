package packModelo;

public abstract class Arma {
}